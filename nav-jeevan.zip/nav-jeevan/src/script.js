// DOM elements
const buyerBtn = document.getElementById('buyer-interface-btn');
const sellerBtn = document.getElementById('seller-interface-btn');
const buyerSection = document.getElementById('buyer-section');
const cartSection = document.getElementById('cart-section');
const checkoutSection = document.getElementById('checkout-section');
const paymentSection = document.getElementById('payment-section');
const cardPaymentSection = document.getElementById('card-payment-section');
const availableProducts = document.getElementById('available-products');
const cartItems = document.getElementById('cart-items');
const placeOrderBtn = document.getElementById('place-order-btn');

// Hide all sections
function hideAllSections() {
    buyerSection.classList.add('hidden');
    checkoutSection.classList.add('hidden');
    paymentSection.classList.add('hidden');
}

// Show Buyer Interface
buyerBtn.addEventListener('click', () => {
    hideAllSections();
    buyerSection.classList.remove('hidden');
    loadProducts();
});

// Back to Main Screen
document.getElementById('back-to-main-4').addEventListener('click', () => {
    hideAllSections();
});

// Load Available Products (example data)
function loadProducts() {
    const products = [
        { name: "Apple", quantity: "10 pieces", price: 200 },
        { name: "Banana", quantity: "12 pieces", price: 100 },
        { name: "Tomato", quantity: "5 pieces", price: 50 }
    ];

    availableProducts.innerHTML = '';
    products.forEach((product, index) => {
        const productHTML = `
            <div class="product">
                <h4>${product.name}</h4>
                <p>Quantity: ${product.quantity}</p>
                <p>Price: ₹${product.price}</p>
                <button class="add-to-cart-btn" data-index="${index}">Add to Cart</button>
            </div>
        `;
        availableProducts.insertAdjacentHTML('beforeend', productHTML);
    });

    document.querySelectorAll('.add-to-cart-btn').forEach((btn) => {
        btn.addEventListener('click', (e) => {
            const productIndex = e.target.getAttribute('data-index');
            addToCart(products[productIndex]);
        });
    });
}

// Add to Cart
let cart = [];
function addToCart(product) {
    cart.push(product);
    updateCart();
}

function updateCart() {
    cartItems.innerHTML = '';
    cart.forEach(item => {
        cartItems.innerHTML += `<p>${item.name} - ₹${item.price} (x${item.quantity})</p>`;
    });
    cartSection.classList.remove('hidden');
}

// Proceed to Checkout
document.getElementById('checkout-btn').addEventListener('click', () => {
    hideAllSections();
    checkoutSection.classList.remove('hidden');
});

// Continue to Payment
document.getElementById('address-form').addEventListener('submit', (e) => {
    e.preventDefault();
    hideAllSections();
    paymentSection.classList.remove('hidden');
});

// Payment Option Toggle
document.querySelectorAll('input[name="payment"]').forEach((radio) => {
    radio.addEventListener('change', (e) => {
        if (e.target.value === 'card') {
            cardPaymentSection.classList.remove('hidden');
        } else {
            cardPaymentSection.classList.add('hidden');
        }
    });
});

// Place Order
placeOrderBtn.addEventListener('click', () => {
    const paymentOption = document.querySelector('input[name="payment"]:checked').value;
    if (paymentOption === 'card') {
        const cardName = document.getElementById('card-name').value;
        const cardNumber = document.getElementById('card-number').value;
        const cardCVV = document.getElementById('card-cvv').value;
        const cardExpiry = document.getElementById('card-expiry').value;
        const cardType = document.getElementById('card-type').value;

        alert(`Order placed using ${cardType.toUpperCase()} card ending in ${cardNumber.slice(-4)}`);
    } else {
        alert(`Order placed using ${paymentOption.toUpperCase()}`);
    }
    cart = [];
    hideAllSections();
});

